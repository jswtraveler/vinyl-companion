var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/serpapi-proxy.js
var serpapi_proxy_exports = {};
__export(serpapi_proxy_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(serpapi_proxy_exports);
var handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      },
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      },
      body: ""
    };
  }
  try {
    let requestData;
    try {
      requestData = JSON.parse(event.body);
    } catch (parseError) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ error: "Invalid JSON in request body" })
      };
    }
    const { imageUrl, apiKey } = requestData;
    if (!imageUrl || !apiKey) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          error: "Missing required fields: imageUrl and apiKey"
        })
      };
    }
    try {
      new URL(imageUrl);
    } catch (urlError) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ error: "Invalid image URL format" })
      };
    }
    const searchParams = new URLSearchParams({
      engine: "google_reverse_image",
      image_url: imageUrl,
      api_key: apiKey,
      ...requestData.options
      // Additional options if provided
    });
    const serpApiUrl = `https://serpapi.com/search?${searchParams.toString()}`;
    console.log("Proxying SerpAPI request for image:", imageUrl);
    const response = await fetch(serpApiUrl, {
      method: "GET",
      headers: {
        "User-Agent": "VinylCompanion-Proxy/1.0 (Netlify Function)",
        "Accept": "application/json"
      }
    });
    if (!response.ok) {
      console.error(`SerpAPI error: ${response.status} ${response.statusText}`);
      let errorBody;
      try {
        errorBody = await response.text();
      } catch (e) {
        errorBody = "Unknown error";
      }
      return {
        statusCode: response.status,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          error: `SerpAPI request failed: ${response.status} ${response.statusText}`,
          details: errorBody
        })
      };
    }
    const data = await response.json();
    if (data.error) {
      console.error("SerpAPI returned error:", data.error);
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          error: "SerpAPI error",
          details: data.error
        })
      };
    }
    console.log("SerpAPI request successful");
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=3600"
        // Cache for 1 hour
      },
      body: JSON.stringify({
        success: true,
        data,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (error) {
    console.error("Proxy function error:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        error: "Proxy function failed",
        details: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
